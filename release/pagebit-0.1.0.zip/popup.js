const status = document.querySelector("#status");
const buttons = [...document.querySelectorAll("button[data-mode]")];
const cancelButton = document.querySelector("#cancel");

function showCapture(progress) {
  const active = !!progress?.active || !!progress?.stage;
  const wasActive = !cancelButton.hidden;
  buttons.forEach(item => { item.disabled = active; });
  cancelButton.hidden = !active;
  if (active) status.textContent = progress.stage || "Capturing...";
  else if (wasActive) status.textContent = "";
}

chrome.runtime.onMessage.addListener(message => {
  if (message?.type === "captureProgress") showCapture(message);
});

chrome.runtime.sendMessage({ type: "captureStatus" })
  .then(showCapture).catch(() => {});

cancelButton.addEventListener("click", async () => {
  cancelButton.disabled = true;
  status.textContent = "Cancelling capture...";
  await chrome.runtime.sendMessage({ type: "cancelCapture" }).catch(() => {});
});

for (const button of buttons) {
  button.addEventListener("click", async () => {
    buttons.forEach((item) => { item.disabled = true; });
    cancelButton.hidden = false;
    status.textContent = "";

    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab?.id) throw new Error("No active tab found.");

      const mode = button.dataset.mode;
      if (mode === "element") {
        await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["select-element.js"] });
        window.close();
        return;
      }

      const response = await chrome.runtime.sendMessage({ type: "capture", mode, tabId: tab.id });
      if (!response?.ok) throw new Error(response?.error || "Capture failed.");
      status.style.color = "#176f5b";
      status.textContent = "Opened preview.";
    } catch (error) {
      status.style.color = "#a13b2c";
      status.textContent = error.message || "Capture failed.";
    } finally {
      buttons.forEach((item) => { item.disabled = false; });
      cancelButton.hidden = true;
      cancelButton.disabled = false;
    }
  });
}
